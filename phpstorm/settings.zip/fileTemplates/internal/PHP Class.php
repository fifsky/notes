<?php
/**
 * Created by ${PRODUCT_NAME}.
 * User: 蔡旭东 caixudong@verystar.cn
 * Date: ${DATE} ${TIME}
 */
 
class ${NAME} {

}
